#PhD-SNPg Supplementary Files

The directory contains te files with the dataset used for training
and testing PhD-SNPg.

The genomic location of the variants is referred to the hg38 human 
genome assembly.

There are: 
    - 5 versions of Clinvar012016 for the different cross-validation splitting: 
	Files prediction_snv_set_[1-5].txt
    - 5 versions of NewClinvar032016 for testing:
	Files test_snv_set_[1-5].txt

The clinvar and cross-validations file contains the following information:

SET:  The number of the set in the cross-validation procedure.
CHR:  The chromosome where the variant has been detected.     
POS:  The position of variant. 
MUT:  The variation expressed as wild-type,mutant
REG:  Region of the variation can be coding or non-coding
EFF:  The effect of the variant as reported in Clinvar or having allele frequency >10%.
PRED: The prediction of PhD-SNPg can be Pathogenic or Benign.
PROB: A probability score. If >0.5 the variants is predicted to be 
      Pathogenic.

*Benign: They are the variants that have not Clinvar annotation but are 
added to the cross-validation sets to balance positive and negative classes.
These variants havebeen considered in the evaluation of the performances.

The testing files do not contains the SET column.
